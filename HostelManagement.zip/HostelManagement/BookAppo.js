$(document).ready(function() {
    $('#submit-form').click(function() {
        validateForm();
    });

    function validateForm() {
        const email = $('#email').val();
        const phoneNo = $('#phoneNo').val();
        let isValid = true;

        // Email validation
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $('#email-error').text('Please enter a valid email address.');
            isValid = false;
        } else {
            $('#email-error').text('');
        }

        // Phone number validation
        const phonePattern = /^\d{10}$/;
        if (!phonePattern.test(phoneNo)) {
            $('#phone-error').text('Please enter a valid 10-digit phone number.');
            isValid = false;
        } else {
            $('#phone-error').text('');
        }

        // If the form is valid, submit it and show loading icon
        if (isValid) {
            showLoadingIcon(); // Show loading icon
            submitForm();
        }
    }

    async function submitForm() {
        const formData = {
            name: $('#name').val(),
            email: $('#email').val(),
            phoneNo: $('#phoneNo').val(),
            date: $('#date').val(),
            time: $('#time').val(),
            selectdr: $('#selectdr').val()
        };

        console.log("Form Data:", formData);

        try {
            const response = await fetch("http://localhost:8080/api/book-appo/book", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(formData)
            });

            const data = await response.text();

            console.log("Response Data:", data);

            if (!response.ok) {
                Swal.fire({
                    title: 'Error!',
                    text: data,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                hideLoadingIcon(); // Hide loading icon on error
                return;
            }

            Swal.fire({
                title: 'Appointment Booked Successfully!',
                text: data,
                icon: 'success',
                confirmButtonText: 'OK'
            });

            hideLoadingIcon(); // Hide loading icon on success
            
        } catch (error) {
            console.error("Error:", error);
            
            Swal.fire({
                title: 'Error!',
                text: "An error occurred while submitting the form.",
                icon: 'error',
                confirmButtonText: 'OK'
            });

            hideLoadingIcon(); // Hide loading icon on error
        }
    }

    function showLoadingIcon() {
        $('#loading-icon').show(); // Show the loading icon
    }

    function hideLoadingIcon() {
        $('#loading-icon').hide(); // Hide the loading icon
    }
});
