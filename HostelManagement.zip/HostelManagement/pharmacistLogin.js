function login() {
    const username = $("#username").val();
    const password = $("#password").val();

    if (username === "pharmacist" && password === "pharmacist123") {
        Swal.fire({
            icon: 'success',
            title: 'Login Successful',
            showConfirmButton: false,
            timer: 1500
        }).then(() => {
            window.location.href = './pharmacistDashboard.html';
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Invalid Credentials',
            text: 'Please check your username and password and try again.'
        });
    }
}
