$(document).ready(function() {
    // Fetch all appointments and populate the dropdown
    fetchAppointments();

    // Handle patient selection change
    $('#patientAppointment').change(function() {
        const selectedAppointment = $(this).find(':selected').data('appointment');
        if (selectedAppointment) {
            $('#patientName').val(selectedAppointment.name);
            $('#doctorName').val(selectedAppointment.selectdr);
            $('#date').val(selectedAppointment.date);
        } else {
            $('#patientName').val('');
            $('#doctorName').val('');
            $('#date').val('');
        }
    });

    // Handle form submission
    $('#prescriptionForm').submit(function(event) {
        event.preventDefault();
        savePrescription();
    });
});

// Function to fetch all appointments
function fetchAppointments() {
    $.get('http://localhost:8080/api/book-appo/get-all', function(data) {
        const appointmentDropdown = $('#patientAppointment');
        appointmentDropdown.empty();
        appointmentDropdown.append('<option value="">Select a Patient</option>');
        data.forEach(function(appointment) {
            const option = $('<option></option>').attr('value', appointment.id).data('appointment', appointment);
            option.text(`${appointment.name} - ${appointment.selectdr} - ${appointment.date}`);
            appointmentDropdown.append(option);
        });
    });
}

// Function to save prescription
async function savePrescription() {
    const patientName = $('#patientName').val();
    const doctorName = $('#doctorName').val();
    const date = $('#date').val();
    const prescription = $('#prescription').val();

    if (!patientName || !doctorName || !date || !prescription) {
        Swal.fire({
            title: 'Error!',
            text: 'All fields are required.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        return;
    }

    const url = "http://localhost:8080/api/prescriptions";

    const payload = {
        patientName: patientName,
        doctorName: doctorName,
        date: date,
        prescription: prescription
    };

    try {
        const fetchResult = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!fetchResult.ok) {
            throw new Error('Failed to save prescription.');
        }

        Swal.fire({
            title: 'Success!',
            text: 'Prescription saved successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        });

        // Clear the form fields
        $('#prescriptionForm')[0].reset();
        $('#patientAppointment').val('');
    } catch (error) {
        Swal.fire({
            title: 'Error!',
            text: `Error: ${error.message}`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}
