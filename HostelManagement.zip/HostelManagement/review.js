document.addEventListener('DOMContentLoaded', () => {
    const reviewForm = document.getElementById('reviewForm');
    const reviewsList = document.getElementById('reviewsList');
    const loadingIcon = document.getElementById('loading-icon');

    // Fetch existing reviews from the backend
    fetch('http://localhost:8080/api/testimonials')
        .then(response => response.json())
        .then(data => {
            data.forEach(review => {
                const reviewBox = createReviewBox(review.patientName, review.review, review.rating);
                reviewsList.appendChild(reviewBox);
            });
        });

    reviewForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        // Show loading icon
        loadingIcon.style.display = 'block';

        const patientName = document.getElementById('patientName').value;
        const review = document.getElementById('review').value;
        const rating = document.querySelector('input[name="rating"]:checked')?.value || '0';

        const newReview = {
            patientName: patientName,
            review: review,
            rating: parseInt(rating)
        };

        // Submit the new review to the backend
        fetch('http://localhost:8080/api/testimonials', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newReview)
        })
        .then(response => response.json())
        .then(data => {
            const reviewBox = createReviewBox(data.patientName, data.review, data.rating);
            reviewsList.appendChild(reviewBox);
            reviewForm.reset();

            // Hide loading icon
            loadingIcon.style.display = 'none';

            // Show SweetAlert
            Swal.fire({
                title: 'Review Submitted',
                text: 'Thank you for your feedback!',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        })
        .catch(error => {
            // Hide loading icon
            loadingIcon.style.display = 'none';

            // Show SweetAlert for error
            Swal.fire({
                title: 'Error',
                text: 'An error occurred while submitting your review. Please try again.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        });
    });

    function createReviewBox(patientName, review, rating) {
        const reviewBox = document.createElement('div');
        reviewBox.classList.add('review-item');

        // Create star elements based on rating
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsHtml += '★';
            } else {
                starsHtml += '☆';
            }
        }

        reviewBox.innerHTML = `
            <h4>${patientName}</h4>
            <div class="rating-display">${starsHtml}</div>
            <p>${review}</p>
        `;

        return reviewBox;
    }
});
