document.addEventListener("DOMContentLoaded", function() {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  
    // Scroll-to-Top Button functionality
    const scrollTopBtn = document.getElementById('scrollTopBtn');
  
    window.onscroll = function() {
      if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        scrollTopBtn.style.display = "block";
      } else {
        scrollTopBtn.style.display = "none";
      }
    };
  
    scrollTopBtn.onclick = function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
  
    // Background Image Slider
    const images = [
      "./Hsopitalbg.jpg",
      "./Hsopitalbg1.jpg",
      "./Hsopitalbg2.jpg",
      "./Hsopitalbg3.jpg",
    ];
  
    let currentIndex = 0;
    const div1 = document.getElementById('div1');
  
    function changeBackgroundImage() {
      div1.style.backgroundImage = `url(${images[currentIndex]})`;
      currentIndex = (currentIndex + 1) % images.length;
    }
  
    setInterval(changeBackgroundImage, 5000);
    changeBackgroundImage(); // Initial call to set the first image
  });
  