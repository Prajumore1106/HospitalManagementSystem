$(document).ready(function() {
    // Event listener for search button
    $('#searchButton').click(function() {
        getPatient();
    });

    // Event listener for delete all patients button
    $('.delete-button').click(function() {
        deleteAllPatients();
    });
});

// Function to fetch all patients
async function getAllPatients() {
    const url = "http://localhost:8080/api/book-appo/get-all";

    try {
        const fetchResult = await fetch(url, { method: 'GET' });
        if (!fetchResult.ok) {
            throw new Error('Failed to fetch all patients.');
        }

        const data = await fetchResult.json();
        displayPatients(data, 'allPatients', true);
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}
// Function to search for a patient by name
async function getPatient() {
    const patientName = $('#patientName').val();

    if (!patientName) {
        Swal.fire({
            title: 'Error!',
            text: 'Please enter a patient name.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        return;
    }

    const url = `http://localhost:8080/api/book-appo/get-by-name/${encodeURIComponent(patientName)}`;

    try {
        const fetchResult = await fetch(url, { method: 'GET' });
        if (!fetchResult.ok) {
            throw new Error('Patient not found!');
        }

        const data = await fetchResult.json();
        if (data.length === 0) {
            Swal.fire({
                title: 'No Results',
                text: 'No patient found with the provided name.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
            return;
        }

        displayPatients(data, 'result-div', false);
    } catch (error) {
        Swal.fire({
            title: 'Error!',
            text: `Error: ${error.message}`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}


// Function to display patients in a table format
function displayPatients(data, elementId, isAllPatients) {
    let tableHeaders;
    if (isAllPatients) {
        tableHeaders = `
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Date</th>
            <th>Time</th>
            <th>Doctor</th>
            <th>Fee</th>
            <th>Actions</th>
        `;
    } else {
        tableHeaders = `
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
        `;
    }

    let patientsHtml = `
        <table>
            <thead>
                <tr>${tableHeaders}</tr>
            </thead>
            <tbody>
    `;

    data.forEach(patient => {
        patientsHtml += `
            <tr>
                <td>${patient.id}</td>
                <td>${patient.name}</td>
                <td>${patient.email}</td>
                <td>${patient.phoneNo}</td>
        `;

        if (isAllPatients) {
            patientsHtml += `
                <td>${patient.date}</td>
                <td>${patient.time}</td>
                <td>${patient.selectdr}</td>
                <td>${patient.fee}</td>
                <td>
                    <button class="cancel-button" onclick="cancelAppointment('${patient.email}')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </td>
            `;
        }

        patientsHtml += `</tr>`;
    });

    patientsHtml += `
            </tbody>
        </table>
    `;

    document.getElementById(elementId).innerHTML = patientsHtml;
    document.getElementById(elementId).scrollIntoView({ behavior: 'smooth' }); // Scroll to the respective section
}

// Function to cancel appointment by email
async function cancelAppointment(email) {
    try {
        const response = await fetch(`http://localhost:8080/api/book-appo/cancel-by-email/${email}`, {
            method: "DELETE",
        });

        const data = await response.text();

        if (!response.ok) {
            throw new Error(data);
        }

        // Update UI after successful cancellation
        await getAllPatients(); // Refresh the patient list
        Swal.fire({
            title: 'Success!',
            text: 'Appointment canceled successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        });

    } catch (error) {
        console.error("Error:", error);

        Swal.fire({
            title: 'Error!',
            text: `Failed to cancel appointment: ${error.message}`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}

// Function to delete all patients
async function deleteAllPatients() {
    try {
        const response = await fetch(`http://localhost:8080/api/book-appo/delete-all`, {
            method: "DELETE",
        });

        const data = await response.text();

        if (!response.ok) {
            throw new Error(data);
        }

        // Update UI after successful deletion
        document.getElementById("allPatients").innerHTML = ''; // Clear patient list
        Swal.fire({
            title: 'Success!',
            text: 'All patients deleted successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        });

    } catch (error) {
        console.error("Error:", error);

        Swal.fire({
            title: 'Error!',
            text: `Failed to delete patients: ${error.message}`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}

