function login() {
    const username = $("#username").val();
    const password = $("#password").val();

    if (username === "admin" && password === "admin123") {
        Swal.fire({
            icon: 'success',
            title: 'Login Successful',
            showConfirmButton: false,
            timer: 1500
        }).then(() => {
            window.location.href = './doctor.html';
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Invalid Credentials',
            text: 'Please check your username and password and try again.'
        });
    }
}
