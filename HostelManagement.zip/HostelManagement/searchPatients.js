$(document).ready(function() {
    // Event listener for search button
    $('#searchButton').click(function() {
        getPatient();
    });
});

// Function to search for a patient by name
async function getPatient() {
    const patientName = $('#patientName').val();

    if (!patientName) {
        Swal.fire({
            title: 'Error!',
            text: 'Please enter a patient name.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        return;
    }

    const url = `http://localhost:8080/api/book-appo/get-by-name/${encodeURIComponent(patientName)}`;

    try {
        const fetchResult = await fetch(url, { method: 'GET' });
        if (!fetchResult.ok) {
            throw new Error('Patient not found!');
        }

        const data = await fetchResult.json();
        if (data.length === 0) {
            Swal.fire({
                title: 'No Results',
                text: 'No patient found with the provided name.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
            return;
        }

        displayPatients(data, 'result-div', false);
    } catch (error) {
        Swal.fire({
            title: 'Error!',
            text: `Error: ${error.message}`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}

// Function to display patients in a table format
function displayPatients(data, elementId, isAllPatients) {
    let tableHeaders = `
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
    `;

    let patientsHtml = `
        <table>
            <thead>
                <tr>${tableHeaders}</tr>
            </thead>
            <tbody>
    `;

    data.forEach(patient => {
        patientsHtml += `
            <tr>
                <td>${patient.id}</td>
                <td>${patient.name}</td>
                <td>${patient.email}</td>
                <td>${patient.phoneNo}</td>
            </tr>
        `;
    });

    patientsHtml += `
            </tbody>
        </table>
    `;

    document.getElementById(elementId).innerHTML = patientsHtml;
    document.getElementById(elementId).scrollIntoView({ behavior: 'smooth' }); // Scroll to the respective section
}
