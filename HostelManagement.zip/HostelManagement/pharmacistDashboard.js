$(document).ready(function() {
    // Optional: Add any initialization code here if needed
});

// Function to search for prescriptions by patient name
async function searchPrescriptions() {
    const patientName = $("#patientName").val();

    try {
        const fetchResult = await fetch(`http://localhost:8080/api/prescriptions?patientName=${encodeURIComponent(patientName)}`, { method: 'GET' });
        if (!fetchResult.ok) {
            throw new Error('Failed to fetch prescriptions.');
        }

        const data = await fetchResult.json();

        if (data.length === 0) {
            // No prescriptions found, show error message
            Swal.fire({
                title: 'No Results!',
                text: `No prescriptions found for patient name "${patientName}".`,
                icon: 'info',
                confirmButtonText: 'OK'
            });
        } else {
            // Display prescriptions
            displayPrescriptions(data);
        }
    } catch (error) {
        Swal.fire({
            title: 'Error!',
            text: `Could not retrieve prescriptions: ${error.message}. Please try again.`,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
}

// Function to display prescriptions in a table format
function displayPrescriptions(data) {
    let tableHeaders = `
        <th>ID</th>
        <th>Patient Name</th>
        <th>Doctor Name</th>
        <th>Date</th>
        <th>Prescription</th>
    `;

    let prescriptionsHtml = `
        <table>
            <thead>
                <tr>${tableHeaders}</tr>
            </thead>
            <tbody>
    `;

    data.forEach(prescription => {
        prescriptionsHtml += `
            <tr>
                <td>${prescription.id}</td>
                <td>${prescription.patientName}</td>
                <td>${prescription.doctorName}</td>
                <td>${prescription.date}</td>
                <td>${prescription.prescription}</td>
            </tr>
        `;
    });

    prescriptionsHtml += `
            </tbody>
        </table>
    `;

    document.getElementById("prescriptionsList").innerHTML = prescriptionsHtml;
    document.getElementById("prescriptionsList").scrollIntoView({ behavior: 'smooth' }); // Scroll to the prescriptions section
}
