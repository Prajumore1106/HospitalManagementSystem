package com.ts.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.ts.model.BookAppo;

@Repository
public interface BookAppoRepository extends JpaRepository<BookAppo, Long> {

    List<BookAppo> findByName(String name);
    List<BookAppo> findByEmail(String email);

    @Transactional
    void deleteAll();

    List<BookAppo> findByDateAndTimeAndSelectdr(LocalDate date, LocalTime time, String selectdr);
}
