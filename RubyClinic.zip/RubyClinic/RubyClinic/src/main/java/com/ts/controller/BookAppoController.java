package com.ts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.ts.model.BookAppo;
import com.ts.service.BookAppoService;

@RestController
@RequestMapping("/api/book-appo")
@CrossOrigin("*")
public class BookAppoController {

    @Autowired
    private BookAppoService bookAppoService;

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@RequestBody BookAppo bookAppo) {
        return bookAppoService.bookApooTime(bookAppo);
    }

    @GetMapping("/get-by-name/{name}")
    public ResponseEntity<List<BookAppo>> getPatientsByName(@PathVariable String name) {
        List<BookAppo> patients = bookAppoService.getPaitentByName(name);
        if (!patients.isEmpty()) {
            return ResponseEntity.ok(patients);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/delete-all")
    public ResponseEntity<String> deleteAllPatients() {
        return bookAppoService.deleteAllPatients();
    }

    @DeleteMapping("/cancel-by-email/{email}")
    public ResponseEntity<String> cancelAppointmentByEmail(@PathVariable String email) {
        return bookAppoService.cancelAppointmentByEmail(email);
    }

    @GetMapping("/get-all")
    public ResponseEntity<List<BookAppo>> getAllPatients() {
        List<BookAppo> patients = bookAppoService.getAllAppointment();
        if (!patients.isEmpty()) {
            return ResponseEntity.ok(patients);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
