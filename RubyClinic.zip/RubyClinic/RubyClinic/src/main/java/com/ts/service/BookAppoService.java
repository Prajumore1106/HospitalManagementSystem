package com.ts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.ts.model.BookAppo;
import com.ts.repository.BookAppoRepository;

@Service
public class BookAppoService {

    @Autowired
    private BookAppoRepository bookAppoRepository;
    
    @Autowired
    private JavaMailSender emailSender;

    public ResponseEntity<String> bookApooTime(BookAppo bookAppo) {
        LocalTime appointmentTime = bookAppo.getTime();
        LocalDate appointmentDate = bookAppo.getDate();
        LocalTime openingTime = LocalTime.of(10, 0);
        LocalTime closingTime = LocalTime.of(23, 0);

        if (appointmentTime.isBefore(openingTime) || appointmentTime.isAfter(closingTime)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Hospital working hours are from 10 AM to 11 PM.");
        }

        List<BookAppo> overlappingAppointments = bookAppoRepository.findByDateAndTimeAndSelectdr(appointmentDate, appointmentTime, bookAppo.getSelectdr());
        if (!overlappingAppointments.isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("The selected appointment time is already taken by another patient. Please choose a different time.");
        }

        switch (bookAppo.getSelectdr()) {
            case "Dr.Smith(Neurologist)":
                bookAppo.setFee(1000);
                break;
            case "Dr.Jones(Radiologist)":
                bookAppo.setFee(700);
                break;
            case "Dr.Williams(Cardiologist)":
                bookAppo.setFee(1500);
                break;
            case "Dr.Brown(Internists)":
                bookAppo.setFee(1000);
                break;
            case "Dr.Davis(Gynaecology)":
                bookAppo.setFee(2000);
                break;
            default:
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please select a valid doctor.");
        }

        bookAppoRepository.save(bookAppo);

        String patientEmail = bookAppo.getEmail();
        String patientName = bookAppo.getName();
        String doctor = bookAppo.getSelectdr();
        SimpleMailMessage patientMessage = new SimpleMailMessage();
        patientMessage.setTo(patientEmail);
        patientMessage.setSubject("Appointment Confirmation");
        patientMessage.setText("Dear " + (patientName != null ? patientName : "Patient") + ",\n\nYour appointment with " 
                                + (doctor != null ? doctor : "the doctor") + " on " 
                                + (appointmentDate != null ? appointmentDate : "the scheduled date") + " at " 
                                + (appointmentTime != null ? appointmentTime : "the scheduled time") + " has been booked successfully.\n\nRegards,\nHospital Management");
        emailSender.send(patientMessage);

        String ownerEmail = "prajumore1106@gmail.com"; // Replace with the owner's email address
        SimpleMailMessage ownerMessage = new SimpleMailMessage();
        ownerMessage.setTo(ownerEmail);
        ownerMessage.setSubject("New Appointment Booked");
        ownerMessage.setText("A new appointment has been booked by " + (patientName != null ? patientName : "a patient") + " on "
                             + (appointmentDate != null ? appointmentDate : "the scheduled date") + " at " 
                             + (appointmentTime != null ? appointmentTime : "the scheduled time") + ".");
        emailSender.send(ownerMessage);

        return ResponseEntity.ok("Appointment submitted successfully!");
    }
    
    public List<BookAppo> getAllAppointment() {
        return bookAppoRepository.findAll();
    }

    public List<BookAppo> getPaitentByName(String name) {
        return bookAppoRepository.findByName(name);
    }

    public ResponseEntity<String> cancelAppointmentByEmail(String email) {
        List<BookAppo> appointments = bookAppoRepository.findByEmail(email);
        if (!appointments.isEmpty()) {
            for (BookAppo appointment : appointments) {
                bookAppoRepository.delete(appointment);
                sendCancellationEmail(appointment);
                sendCancellationEmailToOwner(appointment);
            }
            return ResponseEntity.ok("Appointments canceled for email: " + email);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    private void sendCancellationEmail(BookAppo appointment) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(appointment.getEmail());
        message.setSubject("Appointment Cancellation");
        message.setText(
            "Dear " + appointment.getName() + ",\n\n" +
            "Your appointment on " + appointment.getDate() + " at " + appointment.getTime() +
            " has been canceled.\n\n" +
            "Regards,\nHospital Management"
        );
        emailSender.send(message);
    }

    private void sendCancellationEmailToOwner(BookAppo appointment) {
        String ownerEmail = "prajumore1106@gmail.com"; // Replace with the owner's email address
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(ownerEmail);
        message.setSubject("Appointment Cancellation Notification");
        message.setText(
            "The following appointment has been canceled:\n\n" +
            "Patient Name: " + appointment.getName() + "\n" +
            "Doctor: " + appointment.getSelectdr() + "\n" +
            "Date: " + appointment.getDate() + "\n" +
            "Time: " + appointment.getTime() + "\n\n" +
            "Regards,\nHospital Management"
        );
        emailSender.send(message);
    }

    @Transactional
    public ResponseEntity<String> deleteAllPatients() {
        bookAppoRepository.deleteAll();
        return ResponseEntity.ok("All patients deleted successfully");
    }
}
