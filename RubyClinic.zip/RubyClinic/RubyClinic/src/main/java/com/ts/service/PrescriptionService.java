package com.ts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ts.model.Prescription;
import com.ts.repository.PrescriptionRepository;

import java.util.List;

@Service
public class PrescriptionService {

    @Autowired
    private PrescriptionRepository prescriptionRepository;

    public ResponseEntity<String> savePrescription(Prescription prescription) {
        prescriptionRepository.save(prescription);
        return ResponseEntity.ok("Prescription saved successfully.");
    }

    public List<Prescription> findPrescriptionsByPatientName(String patientName) {
        return prescriptionRepository.findByPatientName(patientName);
    }
}
