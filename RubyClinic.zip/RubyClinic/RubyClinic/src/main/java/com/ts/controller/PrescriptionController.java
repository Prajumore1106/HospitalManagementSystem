package com.ts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ts.model.Prescription;
import com.ts.service.PrescriptionService;

@RestController
@RequestMapping("/api/prescriptions")
@CrossOrigin("*")
public class PrescriptionController {

    @Autowired
    private PrescriptionService prescriptionService;

    @PostMapping
    public ResponseEntity<String> savePrescription(@RequestBody Prescription prescription) {
        return prescriptionService.savePrescription(prescription);
    }
    
    @GetMapping
    public ResponseEntity<List<Prescription>> findPrescriptionsByPatientName(@RequestParam String patientName) {
        List<Prescription> prescriptions = prescriptionService.findPrescriptionsByPatientName(patientName);
        return ResponseEntity.ok(prescriptions);
    }


}
